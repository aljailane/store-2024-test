<?php

// تعريف معرف العميل
$clientId = "AYpuTnwgUtrqAT3rJNq4NwnUFiCU1pSR3xPNbz_O4GNlxxBHoAO6kFGWxuMXrqsJ9liFFkiZAYkejjii";

// تشفير معرف العميل باستخدام Base64
$encodedClientId = base64_encode($clientId);

?>
